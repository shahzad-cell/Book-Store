import mongoose from "mongoose";

//Schema

const bookSchema = mongoose.Schema({
    name: String,
    price: Number,
    category: String,
    image: String,
    title: String
});

//Models

const Book = mongoose.model("Book", bookSchema);

export default Book;